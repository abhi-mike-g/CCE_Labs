package com.example.loginpage;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {

    TextView welcomeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        welcomeText = findViewById(R.id.welcome_text);

        // Get the username from the Intent
        String username = getIntent().getStringExtra("USERNAME");

        // Display Welcome message
        welcomeText.setText("Welcome " + username);
    }
}
